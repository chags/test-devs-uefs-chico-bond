/**
 * @prettier
 */
const stringTypeCaster = (value) => String(value)

export default stringTypeCaster
